// This file was generated automatically by Modkit MSIE.
var HackedFonts = [
    {
        "family": "New Geneva W01 Nine",
        "primary": "d29907c8-c47d-45b0-8caf-210b1d1811f9.eot",
        "sources": [
            "d29907c8-c47d-45b0-8caf-210b1d1811f9.woff2",
            "d29907c8-c47d-45b0-8caf-210b1d1811f9.woff",
            "d29907c8-c47d-45b0-8caf-210b1d1811f9.ttf"
        ]
    },
    {
        "family": "Sabo",
        "primary": "Sabo-Filled.eot",
        "sources": [
            "Sabo-Filled.IEFix.eot",
            "Sabo-Filled.svg",
            "Sabo-Filled.otf",
            "Sabo-Filled.woff2",
            "Sabo-Filled.woff",
            "Sabo-Filled.ttf"
        ]
    },
    {
        "family": "Sabo-Filled",
        "primary": "Sabo-Filled.eot",
        "sources": [
            "Sabo-Filled.IEFix.eot",
            "Sabo-Filled.svg",
            "Sabo-Filled.otf",
            "Sabo-Filled.woff2",
            "Sabo-Filled.woff",
            "Sabo-Filled.ttf"
        ]
    }
]